#!/bin/bash
QT_PLUGIN_PATH=${PWD}/plugins LD_LIBRARY_PATH=${PWD}:${LD_LIBRARY_PATH} ./bitmail
